# Files to accompany the How deploy Prometheus on Kubernetes video

Find the video at https://www.youtube.com/watch?v=V4ApOm37XCU
